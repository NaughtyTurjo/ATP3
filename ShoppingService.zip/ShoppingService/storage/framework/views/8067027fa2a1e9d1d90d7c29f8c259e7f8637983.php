<table class= "table">
	<tr>
        <th>Title</th>
        <th>Size</th>
        <th>Price</th>
    </tr>
    <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
	<td><?php echo e($shop->title); ?></td>
	<td><?php echo e($shop->size); ?></td>
	<td><?php echo e($shop->price); ?></td>
    </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
</table>
		