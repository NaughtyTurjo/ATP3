
@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    <table class="table">
                        <tr>
                            <td>
                                Name
                            </td>
                            <td>
                                Modify
                            </td>
                        </tr>
                        @foreach($categories as $c)
                        <tr>
                            <td>
                                {{$c->name}}
                            </td>
                            <td>
                            <a href="/category/edit/{id}" class="btn btn-primary">Edit</a>
                            <a href="/category/edit/{id}" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                        @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
