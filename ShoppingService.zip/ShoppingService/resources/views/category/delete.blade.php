@foreach($categories as $c)

@endforeach