<table class= "table">
	<tr>
        <th>Title</th>
        <th>Size</th>
        <th>Price</th>
    </tr>
    @foreach($shops as $shop)
    <tr>
	<td>{{$shop->title}}</td>
	<td>{{$shop->size}}</td>
	<td>{{$shop->price}}</td>
    </tr>
 @endforeach 
</table>
		